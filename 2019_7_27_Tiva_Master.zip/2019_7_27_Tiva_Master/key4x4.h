#define TARGET_IS_TM4C123_RA1
#ifndef KEY4X4_H_
#define KEY4X4_H_

#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"

#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
//#include "driverlib/map.h"
#include "driverlib/sysctl.h"

#define KEY_8_PORT GPIO_PORTB_BASE
#define KEY_8_PIN GPIO_PIN_5

#define KEY_7_PORT GPIO_PORTB_BASE
#define KEY_7_PIN GPIO_PIN_0

#define KEY_6_PORT GPIO_PORTB_BASE
#define KEY_6_PIN GPIO_PIN_1

#define KEY_5_PORT GPIO_PORTE_BASE
#define KEY_5_PIN GPIO_PIN_4

#define KEY_4_PORT GPIO_PORTE_BASE
#define KEY_4_PIN GPIO_PIN_5

#define KEY_3_PORT GPIO_PORTB_BASE
#define KEY_3_PIN GPIO_PIN_4

#define KEY_2_PORT GPIO_PORTA_BASE
#define KEY_2_PIN GPIO_PIN_5

#define KEY_1_PORT GPIO_PORTA_BASE
#define KEY_1_PIN GPIO_PIN_6

#define CLR_KEY_1 ROM_GPIOPinWrite(KEY_1_PORT,KEY_1_PIN,~KEY_1_PIN)
#define SET_KEY_1 ROM_GPIOPinWrite(KEY_1_PORT,KEY_1_PIN,KEY_1_PIN)

#define CLR_KEY_2 ROM_GPIOPinWrite(KEY_2_PORT,KEY_2_PIN,~KEY_2_PIN)
#define SET_KEY_2 ROM_GPIOPinWrite(KEY_2_PORT,KEY_2_PIN,KEY_2_PIN)

#define CLR_KEY_3 ROM_GPIOPinWrite(KEY_3_PORT,KEY_3_PIN,~KEY_3_PIN)
#define SET_KEY_3 ROM_GPIOPinWrite(KEY_3_PORT,KEY_3_PIN,KEY_3_PIN)

#define CLR_KEY_4 ROM_GPIOPinWrite(KEY_4_PORT,KEY_4_PIN,~KEY_4_PIN)
#define SET_KEY_4 ROM_GPIOPinWrite(KEY_4_PORT,KEY_4_PIN,KEY_4_PIN)

#define READ_KEY_5 ROM_GPIOPinRead(KEY_5_PORT,KEY_5_PIN)
#define READ_KEY_6 ROM_GPIOPinRead(KEY_6_PORT,KEY_6_PIN)
#define READ_KEY_7 ROM_GPIOPinRead(KEY_7_PORT,KEY_7_PIN)
#define READ_KEY_8 ROM_GPIOPinRead(KEY_8_PORT,KEY_8_PIN)


void keyinit();
void KeyboardIntHandler();
uint8_t keyscanf();
uint32_t GetKeyNumber(uint8_t ShowWhileInput);



#endif
