

//#ifndef TARGET_IS_TM4C123_RA1
#define TARGET_IS_TM4C123_RA1
#include"key4x4.h"
//#include"LCD12864.h"
#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"


#include"LCD12864_rom_enable.h"

static void pout(uint8_t value)
{
    if(value&0x08)
        SET_KEY_4;
    else
        CLR_KEY_4;
    if(value&0x04)
        SET_KEY_3;
    else
        CLR_KEY_3;
    if(value&0x02)
        SET_KEY_2;
    else
        CLR_KEY_2;
    if(value&0x01)
        SET_KEY_1;
    else
        CLR_KEY_1;
}
static uint8_t pin()
{
    uint8_t data=0;
    if(READ_KEY_8)
        data|=0x80;
    if(READ_KEY_7)
        data|=0x40;
    if(READ_KEY_6)
        data|=0x20;
    if(READ_KEY_5)
        data|=0x10;
    return data;
}

uint8_t keyscanf()
{
    uint8_t Key_value=0;
    uint8_t row,col;
    uint8_t temp1=0x08,temp2=0x80;
    for(row=0;row<4;row++)
    {
        temp2=0x80;
        pout(~temp1);
        temp1>>=1;
        if((pin()&0xf0)<=0xf0)
        {
            temp2=0x80;
            for(col=0;col<4;col++)
            {
                if((pin()&temp2)==0x00)
                {
                    Key_value=col*4+row+1;
                    return Key_value;
                }
                temp2>>=1;

            }
        }
    }
    __delay_cycles(20000);
	return Key_value;
}

void keyinit()
{
    /*
     * 1-4 output
     */
//	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOL);
//	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOQ);



	GPIOPinTypeGPIOOutput(KEY_1_PORT,KEY_1_PIN);
	GPIOPinTypeGPIOOutput(KEY_2_PORT,KEY_2_PIN);
	GPIOPinTypeGPIOOutput(KEY_3_PORT,KEY_3_PIN);
	GPIOPinTypeGPIOOutput(KEY_4_PORT,KEY_4_PIN);

	SET_KEY_1;
	SET_KEY_2;
	SET_KEY_3;
	SET_KEY_4;


    /*
     * 5-8 input
     */
	GPIOPinTypeGPIOInput(KEY_5_PORT,KEY_5_PIN);
	GPIOPinTypeGPIOInput(KEY_6_PORT,KEY_6_PIN);
	GPIOPinTypeGPIOInput(KEY_7_PORT,KEY_7_PIN);
	GPIOPinTypeGPIOInput(KEY_8_PORT,KEY_8_PIN);

	GPIOPadConfigSet(KEY_5_PORT, KEY_5_PIN,
	                     GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
	GPIOPadConfigSet(KEY_6_PORT, KEY_6_PIN,
	                     GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
	GPIOPadConfigSet(KEY_7_PORT, KEY_7_PIN,
	                     GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
	GPIOPadConfigSet(KEY_8_PORT, KEY_8_PIN,
	                     GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);




	IntMasterEnable();

	GPIOIntTypeSet(KEY_5_PORT,KEY_5_PIN,GPIO_RISING_EDGE);
    GPIOIntClear(KEY_5_PORT,KEY_5_PIN);
	GPIOIntRegister(KEY_5_PORT,KeyboardIntHandler);
	GPIOIntEnable(KEY_5_PORT,KEY_5_PIN);
	GPIOIntClear(KEY_5_PORT,KEY_5_PIN);
	GPIOIntDisable(KEY_5_PORT,KEY_5_PIN);//Ĭ�Ϲر� �����ж�
}

void KeyboardIntHandler()
{
	//uint8_t keymap[16]={1,2,3,'A',4,5,6,'B',7,8,9,'C','*','#',0,'D'};
    uint32_t Key_value;
    uint8_t temp;
    __delay_cycles(10000);
 	while((temp=keyscanf())!=0);
//	if(GPIOPinRead(KEY_5_PORT,KEY_5_PIN|KEY_6_PIN|KEY_7_PIN|KEY_8_PIN)>0)
//	{
		Key_value=GetKeyNumber(1);

//	}
	GPIOIntClear(KEY_5_PORT,KEY_5_PIN);
}


uint32_t GetKeyNumber(uint8_t ShowWhileInput)//ɨ��ʽ
{
    uint8_t temp;
    uint32_t data=0;
    uint8_t len=0;
    uint8_t x=8;
    uint8_t y=36;
    if(ShowWhileInput)
    {
        DispClear_line(8,1,128);
        DispString5x8(8,1,"input:",1);
    }
    __delay_cycles(1000000);
    while((temp=keyscanf())!=15)//#�Ž���
    {

        if(temp!=0)//��ʾ�а�������
        {
           switch(temp)
              {
                 case 1:
                       data=data*10+1;
                   if(ShowWhileInput) DispNumber5x8(x,y+6*len,1,0);
                   break;
                case 2:
                       data=data*10+2;
                       if(ShowWhileInput) DispNumber5x8(x,y+6*len,2,0);
                       break;
                case 3:data=data*10+3;
                       if(ShowWhileInput) DispNumber5x8(x,y+6*len,3,0);
                           break;
                //   case 4:data=data*10+4;break;
                 case 5:data=data*10+4;
                   if(ShowWhileInput) DispNumber5x8(x,y+6*len,4,0);
                   break;
                 case 6:data=data*10+5;
                   if(ShowWhileInput) DispNumber5x8(x,y+6*len,5,0);
                   break;
                 case 7:data=data*10+6;
                   if(ShowWhileInput) DispNumber5x8(x,y+6*len,6,0);
                   break;
                 //  case 8:data=data*10+8;break;
                 case 9:data=data*10+7;
                   if(ShowWhileInput) DispNumber5x8(x,y+6*len,7,0);
                   break;
                 case 10:data=data*10+8;
                   if(ShowWhileInput) DispNumber5x8(x,y+6*len,8,0);
                   break;
                 case 11:data=data*10+9;
                   if(ShowWhileInput) DispNumber5x8(x,y+6*len,9,0);
                   break;
                 //  case 12:data=data*10+9;break;
                 //  case 13:data=data*10+9;break;
                 //  case 14:data=data*10+9;break;
                   case 14:data=data*10+0;
                   if(ShowWhileInput) DispNumber5x8(x,y+6*len,0,0);
                   break;
                  // case 16:data=data*10+0;break;
                   default :break;
                  // case 1:data=data*10+1;break;
                   }
           len++;
           while(keyscanf()!=0);//�ȴ�������
        }

      //  len=0;
    }
    while(keyscanf()!=0);//�ȴ�����15�ص�
    if(ShowWhileInput)
    {
        DispClear_line(8,1,128);
        DispString5x8(8,1,"value:",1);
        DispNumber5x8(8,36,data,1);
    }
    return data;
}
//#endif
