#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "string.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include "driverlib/adc.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "key4x4.h"
#include "uartstdio.h"
#include "driverlib/uart.h"
#include "driverlib/timer.h"
#include "LCD12864_rom_enable.h"
#include "driverlib/interrupt.h"
#include "fft.h"

unsigned int flag_0 = 0;

void Timer0IntHandler(void);
void UART3IntHandler(void);
void KeyProcessor(void);
void Key_x(uint8_t x);
void Key_A(void);
void Key_B(void);
void Key_C(void);
void Key_D(void);
void Key_E(void);
void Key_F(void);
void Key_STAR(void);
void Key_PPPP(void);

uint8_t KeyValue;

uint8_t sin_table[88] = {32,   34, 36, 38, 41, 43, 45, 47, 49, 51, 52, 54, 56, 57, 58, 60, 61, 61,
                  62, 63, 63, 63, 64, 63, 63, 63, 62, 61, 61, 60, 58, 57, 56, 54, 52, 51, 49,
                  47, 45, 43, 41, 38, 36, 34, 32, 29, 27, 25, 22, 20, 18, 16, 14, 12, 11, 9,
                  7,  6,  5,  3,  2,  2,  1,  0,  0,  0,  0,  0,  0,  0,  1,  2,  2,  3,  5,
                  6,  7,  9,  11, 12, 14, 16, 18, 20, 22, 25, 27, 29,
};

uint32_t pui32ADC0Value[1];

uint32_t pui32ADC0Temp[64];
uint8_t pui32ADC0Show[64];
complex C_in[64];
complex C_out[64];
float mo[64];
int C_mo_int[64];

union result
{
    unsigned int uint_32;
    float float_32;
    char char_8[4];
}r0,r1,r2,r3,r4;
unsigned char t_flag;
int uart_i=0;
int cnt = 0;
int ADC_i=0;

float max =0;
int main()
{

    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
   //ʹ��TIMER0


//
    TimerConfigure(TIMER0_BASE, TIMER_CFG_A_PERIODIC);//�����Լ���ģʽ
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);//�����Լ���ģʽ


    TimerLoadSet(TIMER0_BASE, TIMER_A,SysCtlClockGet()/8 - 1);//����Ƶ��10HZ
    IntEnable(INT_TIMER0A);//NVIC
    //ʹ��TIMER0A
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    //TIMEOUT��־λ�����ж�


    //Ϊ��ʱ��ָ���жϴ�������
    TimerIntRegister(TIMER0_BASE,TIMER_A,Timer0IntHandler);
       //master interrupt enable API for all interrupts
    TimerEnable(TIMER0_BASE, TIMER_A);
       //TIMER0A��ʼ������������ֵ����TimerLoadSet�������ж�
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);


    HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY;
    HWREG(GPIO_PORTF_BASE + GPIO_O_CR) |= GPIO_PIN_0; //PortF����


    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART3);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOC));
    GPIOPinConfigure(GPIO_PC6_U3RX);
    GPIOPinConfigure(GPIO_PC7_U3TX);
    GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_6);
    GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_7);

    UARTStdioConfig(3,115200, SysCtlClockGet());
    UARTConfigSetExpClk(UART3_BASE, SysCtlClockGet(), 115200,
    (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
    UARTEnable(UART3_BASE);


    UARTFIFODisable(UART3_BASE);
//    //ʹ��UART0�ж�

//    //ʹ��UART0�����ж�
//
    UARTIntEnable(UART3_BASE,UART_INT_RX);
//    //UART�жϵ�ַע��
//
    UARTIntRegister(UART3_BASE,UART3IntHandler);


    IntEnable(INT_UART3);

    GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_7);




//    //ȫ���ж�ʹ��
    IntMasterEnable();




    lcd12864_init();
    DispClear();
    DispString5x8(1,1,"LCD_Test",true);
    keyinit();

    while(1)
    {

//        DispFloat5x8(3,1,3.123456,true,6);
//        display_vertical_line(50,10,true);



    }

}
void Timer0IntHandler(void)
{
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    DispClear();
    KeyProcessor();
    DispNumber5x8(4,100,cnt,true);
//    DispChar5x8(5,1,UART3_RX_temp,true);
    DispNumber5x8(2,1,r0.uint_32,true);
    DispNumber5x8(3,1,r1.uint_32,true);
    DispNumber5x8(4,1,r2.uint_32,true);
    DispNumber5x8(5,1,r3.uint_32,true);
    DispFloat5x8(6,1,r4.float_32,true,4);
}

void UART3IntHandler(void)
{
    //��ȡ�жϱ�־ ԭʼ�ж�״̬ �����жϱ�־
    uint32_t flag = UARTIntStatus(UART3_BASE,true);
    //����жϱ�־
    UARTIntClear(UART3_BASE,flag);


//
    while(UARTCharsAvail(UART3_BASE))
    {
        t_flag=UARTgetc();

        switch(t_flag)
        {
            case 10:
                r0.char_8[0]=UARTgetc();
                r0.char_8[1]=UARTgetc();
                r0.char_8[2]=UARTgetc();
                r0.char_8[3]=UARTgetc();
                break;
            case 11:
                r1.char_8[0]=UARTgetc();
                r1.char_8[1]=UARTgetc();
                r1.char_8[2]=UARTgetc();
                r1.char_8[3]=UARTgetc();
                break;
            case 12:
                r2.char_8[0]=UARTgetc();
                r2.char_8[1]=UARTgetc();
                r2.char_8[2]=UARTgetc();
                r2.char_8[3]=UARTgetc();
                break;
            case 13:
                r3.char_8[0]=UARTgetc();
                r3.char_8[1]=UARTgetc();
                r3.char_8[2]=UARTgetc();
                r3.char_8[3]=UARTgetc();
                break;
            case 14:
                r4.char_8[0]=UARTgetc();
                r4.char_8[1]=UARTgetc();
                r4.char_8[2]=UARTgetc();
                r4.char_8[3]=UARTgetc();
                break;
        }
    }

}

void KeyProcessor(void)
{
    KeyValue= keyscanf();
    __delay_cycles(10);

    switch(KeyValue)
    {
        case  1:Key_x(1);break;// 1
        case  2:Key_x(2);break;// 2
        case  3:Key_x(3);break;// 3
        case  4:Key_A( );break;// A
        case  5:Key_x(4);break;// 4
        case  6:Key_x(5);break;// 5
        case  7:Key_x(6);break;// 6
        case  8:Key_B( );break;// B
        case  9:Key_x(7);break;// 7
        case 10:Key_x(8);break;// 8
        case 11:Key_x(9);break;// 9
        case 12:Key_C( );break;// C
        case 13:Key_STAR();break;// *
        case 14:Key_x(0);break;// 0
        case 15:Key_PPPP();break;// #
        case 16:Key_D( );break;// D
        default:
            break;
    }
}

void Key_x(uint8_t x)
{
    cnt++;
//    DispNumber5x8(2,1,x,true);
//    DispNumber5x8(4,100,cnt++,true);
    UARTCharPut(UART3_BASE, x+'0');
}
void Key_A(void)
{
    cnt++;
//    DispChar5x8(2,1,'A',true);
//    DispNumber5x8(4,100,cnt++,true);
    UARTCharPut(UART3_BASE,'A');
}
void Key_B(void)
{
    cnt++;
//    DispChar5x8(2,1,'B',true);
//    DispNumber5x8(4,100,cnt++,true);
    UARTCharPut(UART3_BASE,'B');
}
void Key_C(void)
{
    cnt++;
//    DispChar5x8(2,1,'C',true);
//    DispNumber5x8(4,100,cnt++,true);
    UARTCharPut(UART3_BASE,'C');
}
void Key_D(void)
{
    cnt++;
//    DispChar5x8(2,1,'D',true);
//    DispNumber5x8(4,100,cnt++,true);
    UARTCharPut(UART3_BASE,'D');
}
void Key_E(void)
{
    cnt++;
//    DispChar5x8(2,1,'E',true);
//    DispNumber5x8(4,100,cnt++,true);
    UARTCharPut(UART3_BASE,'E');
}
void Key_F(void)
{
    cnt++;
//    DispChar5x8(2,1,'F',true);
//    DispNumber5x8(4,100,cnt++,true);
    UARTCharPut(UART3_BASE,'F');
}
void Key_STAR(void)
{
    cnt++;
//    DispChar5x8(2,1,'*',true);
////    DispNumber5x8(4,1,cnt++,true);
    UARTCharPut(UART3_BASE,'*');


//    UARTgets(UART3_RX_temp,10);
}
void Key_PPPP(void)
{
    cnt++;
//    DispChar5x8(2,1,'#',true);
////    DispNumber5x8(4,1,cnt++,true);
    UARTCharPut(UART3_BASE,'#');
//    DispChar5x8(5,1,UART3_RX_temp,true);


}
